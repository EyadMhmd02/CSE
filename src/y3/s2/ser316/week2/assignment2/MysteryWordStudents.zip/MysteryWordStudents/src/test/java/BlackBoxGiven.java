import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.lang.reflect.Constructor;
import java.util.Arrays;
import java.util.Collection;

import static org.junit.Assert.*;

@RunWith(Parameterized.class)
public class BlackBoxGiven {
    private Class<Game> classUnderTest;

    @SuppressWarnings("unchecked")
    public BlackBoxGiven(Object classUnderTest) {
        this.classUnderTest = (Class<Game>) classUnderTest;
    }

    // Define all classes to be tested
    @Parameterized.Parameters
    public static Collection<Object[]> cartClassUnderTest() {
        Object[][] classes = {
                {Game0.class},
                {Game1.class},
                {Game2.class},
                {Game3.class},
                {Game4.class}
        };
        return Arrays.asList(classes);
    }

    private Game createGame() throws Exception {
        Constructor<Game> constructor = classUnderTest.getConstructor();
        return constructor.newInstance();
    }

    Game game;

    @org.junit.Before
    public void setUp() throws Exception {
        game = createGame();
    }


    @Test
    public void winning() {
        game.initGame("lion", "Dr. M");

        double response = game.makeGuess("lion");
        assertEquals(0.0, response, 0.0);
        assertEquals(14, game.getPoints());
        assertEquals(1, game.getGameStatus());
    }

    @Test
    public void testSingleLetterInWord() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("l");
        assertEquals(1.1, response, 0.0); // 'l' appears once
        assertEquals(11, game.getPoints()); // 10 + 1 point
    }

    @Test
    public void testSingleLetterNotInWord() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("z");
        assertEquals(1.0, response, 0.0); // Letter not in word
        assertEquals(10, game.getPoints()); // No point change
    }

    @Test
    public void testRepeatedLetter() {
        game.initGame("look", "Dr. M");
        double response = game.makeGuess("o");
        assertEquals(1.2, response, 0.0); // 'o' appears twice
        assertEquals(12, game.getPoints()); // 10 + 2 points
    }

    @Test
    public void testCorrectLengthWrongWord() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("bear");
        assertEquals(2.0, response, 0.0); // Same length, wrong word
        assertEquals(11, game.getPoints()); // 10 + 1 point
    }

    @Test
    public void testWordTooLong() {
        game.initGame("cat", "Dr. M");
        double response = game.makeGuess("elephant");
        assertEquals(2.1, response, 0.0); // Too long
        assertTrue(game.getPoints() < 10); // Points reduced
    }

    @Test
    public void testWordTooShort() {
        game.initGame("elephant", "Dr. M");
        double response = game.makeGuess("cat");
        assertEquals(2.2, response, 0.0); // Too short
        assertTrue(game.getPoints() < 10); // Points reduced
    }

    @Test
    public void testPartialMatch() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("li");
        assertEquals(3.0, response, 0.0); // Partial match
        assertEquals(12, game.getPoints()); // 10 + 2 points
    }

    @Test
    public void testAlreadyGuessed() {
        game.initGame("lion", "Dr. M");
        game.makeGuess("l");
        double response = game.makeGuess("l");
        assertEquals(4.0, response, 0.0); // Already guessed
        assertEquals(9, game.getPoints()); // 11 - 2 points
    }

    @Test
    public void testInvalidCharacters() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("l1on");
        assertEquals(4.1, response, 0.0); // Contains numbers
        assertEquals(7, game.getPoints()); // 10 - 3 points
    }

    @Test
    public void testGameOver() {
        game.initGame("lion", "Dr. M");
        // Make 10 wrong guesses
        for (int i = 0; i < 10; i++) {
            game.makeGuess("z" + i);
        }
        double response = game.makeGuess("a");
        assertEquals(5.0, response, 0.0); // Game over
        assertEquals(2, game.getGameStatus()); // Game over status
    }

    @Test
    public void testGuessAfterGameOver() {
        game.initGame("lion", "Dr. M");
        // Make 10 wrong guesses to end game
        for (int i = 0; i < 10; i++) {
            game.makeGuess("z" + i);
        }
        game.makeGuess("a"); // This ends the game
        double response = game.makeGuess("b"); // This should return 5.1
        assertEquals(5.1, response, 0.0);
    }

    @Test
    public void testGuessAfterWin() {
        game.initGame("lion", "Dr. M");
        game.makeGuess("lion"); // Win the game
        double response = game.makeGuess("l"); // Guess after winning
        assertEquals(5.1, response, 0.0);
    }

    @Test
    public void testEmptyGuess() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("");
        assertEquals(4.1, response, 0.0); // Invalid input
    }

    @Test
    public void testCaseInsensitive() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("LION");
        assertEquals(0.0, response, 0.0); // Should be case insensitive
        assertEquals(14, game.getPoints()); // 10 + 4 points for word length
        assertEquals(1, game.getGameStatus()); // Won
    }
}