/*
  File: Game.java
  Author: Eyad Mohamed AbdelMohsen Ghanem
  Date: June 6, 2025

  Description: Class for handling game logic for hangman game.
  Every game starts with a score of 10 and points are reduced/added based on guesses.
  Game is lost when the user made 10 guesses and did not guess the word.
*/

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Class for handling some game logic for hangman game.
 * Every game starts with a score of 10 and the points are reduced based on the description of "makeGuess". Points holds the current score for one game.
 * Game is lost when the user made 10 guesses and did not guess the word.
 *
 */
public class Game {

    /** Holds the points for the game. */
    public int points;

    /** Holds the round of the game. */
    int round;

    /** Holds the player name for the game. */
    String name;

    /** Holds the answer for the current game. */
    String answer;

    /** The path to the file holding the leaderboard.*/
    private String leaderboard = "leaderboard.txt";

    /** The status of the game. {0 - In progress, 1 - Game won, 2 - game over}*/
    protected int gameStatus = 0;

    /** Maximum number of guesses allowed */
    private static final int MAX_GUESSES = 10;

    // all things that were already guessed, needs to be cleared for each game
    ArrayList<String> guesses = new ArrayList<String>();

    // all answers from makeGuess that were already returned
    ArrayList<Double> answers = new ArrayList<Double>();

    /**
     * Gets the name for the game.
     * @return String The name.
     */
    public String getName() {
        return this.name;
    }

    /**
     * Gets the answer for the game.
     * @return String The Answer.
     */
    public String getAnswer() {
        return this.answer.toLowerCase();
    }

    /**
     * Gets the current status of the game.
     * @return int The game status
     */
    public int getGameStatus() {
        return this.gameStatus;
    }

    /**
     * Sets the score for the game.
     * @param points The new point value
     */
    public void setPoints(int points) {
        this.points = points;
    }

    /**
     * Gets the score for the game.
     * @return int The current points
     */
    public int getPoints() {
        return this.points;
    }

    /**
     * Counts the number of letters that have been guessed correctly during the game.
     * The number of correct letter guesses will be returned in result.
     * @return int Number of correct letters found
     */
    public int countCorrectLetters() {
        int result = 0;
        if (!guesses.isEmpty()) {
            for (int i = 0; i < this.answer.length(); i++) {
                String current = String.valueOf(this.answer.charAt(i));
                if (guesses.contains(current)) {
                    System.out.print(this.answer.charAt(i));
                    result++; // Count each position that has been guessed correctly
                } else {
                    System.out.print('_');
                }
            }
            System.out.println();
        } else return 0;
        return result; // Return the calculated result
    }

    /**
     * Counts how often a letter occurs in the answer
     * @param letter The letter to count
     * @return int Number of occurrences
     */
    public int countLetters(char letter) {
        int count = 0;
        int i = 0;
        while (this.getAnswer().indexOf(letter, i) >= 0) {
            i = this.getAnswer().indexOf(letter, i) + 1;
            count++;
        }
        return count;
    }

    /**
     * Constructs a new game with a random word.
     * @param name The player name
     */
    public Game(String name) {
        this.name = name;
        setRandomWord();
        setPoints(10);
    }

    /**
     * Constructs a new game with a given word and given name.
     * @param fixedWord The word to guess
     * @param name The player name
     */
    public Game(String fixedWord, String name) {
        this.name = name;
        this.answer = fixedWord;
        setPoints(10);
    }

    /**
     * Constructs a new game with no arguments, empty name and answer
     */
    public Game() {
        this.name = "";
        this.answer = "";
        setPoints(10);
    }

    /**
     * Sets the name and answers of an already existing game and clears the guesses
     * @param answer The new answer word
     * @param name The new player name
     */
    public void initGame(String answer, String name) {
        this.name = name;
        this.answer = answer;
        this.gameStatus = 0;
        this.guesses.clear();
        this.answers.clear();
        setPoints(10);
    }

    /**
     * Checks if the guess made is correct, should ignore upper/lower case. Should give points based on made guess.
     * Method returns a double, number of the double has different meanings
     * 0 Correct guess
     * 1.x Letter is in the word, x represents the number of times the letter is in the word
     * 2.0 Guess has correct length
     * 2.1 Guess is too long (only if it was a word)
     * 2.2 Guess is too short (only if it was a word)
     * 3.0 Guess is partially included in the word (only if it was a word), given instead of 2.2 if it is a partial word
     * 4.0 This guess was already used
     * 4.1 Guess includes symbols, numbers (not just letters or one letter)
     * 5. After 10 guesses the game ends and is set to game over
     * 5.1 If the player keeps guessing even though the status is not InProgress
     *
     * @param guess The player's guess
     * @return double Returns the appropriate response code
     */
    public double makeGuess(String guess) {
        // Check if game is already over or won
        if (gameStatus != 0) {
            return 5.1;
        }

        // Convert guess to lowercase for consistency
        String lowerGuess = guess.toLowerCase();
        String lowerAnswer = this.getAnswer();

        // Check if already guessed (before adding to list)
        if (guesses.contains(lowerGuess)) {
            setPoints(points - 2);
            return 4.0;
        }

        // Validate input - only letters allowed
        if (!guess.matches("^[a-zA-Z]+$") || guess.isEmpty()) {
            setPoints(points - 3);
            guesses.add(lowerGuess);
            // Check if this invalid guess reaches the limit
            if (guesses.size() >= MAX_GUESSES) {
                gameStatus = 2; // Game over
                return 5.0;
            }
            return 4.1;
        }

        // Add guess to the list
        guesses.add(lowerGuess);

        // Check if we've reached maximum guesses AFTER processing the guess
        boolean gameOverAfterThisGuess = (guesses.size() >= MAX_GUESSES);

        // Single letter guess
        if (guess.length() == 1) {
            char letter = lowerGuess.charAt(0);
            int letterCount = countLetters(letter);

            if (letterCount > 0) {
                setPoints(points + letterCount);
            }

            // Check for game over after processing
            if (gameOverAfterThisGuess) {
                gameStatus = 2; // Game over
                return 5.0;
            }

            return letterCount > 0 ? 1.0 + (letterCount * 0.1) : 1.0;
        }

        // Word guess
        else {
            // Check for exact match (correct word)
            if (lowerGuess.equals(lowerAnswer)) {
                setPoints(points + lowerAnswer.length());
                gameStatus = 1; // Game won
                return 0.0;
            }

            // Check for partial match (substring)
            if (lowerAnswer.contains(lowerGuess)) {
                setPoints(points + 2);
            } else if (lowerGuess.length() == lowerAnswer.length()) {
                setPoints(points + 1);
            } else if (lowerGuess.length() > lowerAnswer.length()) {
                int difference = lowerGuess.length() - lowerAnswer.length();
                setPoints(points - difference);
            } else {
                int difference = lowerAnswer.length() - lowerGuess.length();
                setPoints(points - difference);
            }

            // Check for game over after processing
            if (gameOverAfterThisGuess) {
                gameStatus = 2; // Game over
                return 5.0;
            }

            // Return appropriate code based on word analysis
            if (lowerAnswer.contains(lowerGuess)) {
                return 3.0; // Partial match
            } else if (lowerGuess.length() == lowerAnswer.length()) {
                return 2.0; // Same length, wrong word
            } else if (lowerGuess.length() > lowerAnswer.length()) {
                return 2.1; // Too long
            } else {
                return 2.2; // Too short
            }
        }
    }

    /**
     * Pulls out a random animal and sets it as answer
     */
    public void setRandomWord() {
        String[] animals = {"dog", "horse", "pony", "cat", "lion", "bear", "lioncub"};
        int randomNum = (int) (Math.random() * animals.length);
        this.answer = animals[randomNum];
    }
}