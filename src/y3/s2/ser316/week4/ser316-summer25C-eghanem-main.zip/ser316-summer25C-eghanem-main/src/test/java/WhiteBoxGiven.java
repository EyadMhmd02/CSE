import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class WhiteBoxGiven {
    Game game;

    @Before
    public void setUp() throws Exception {
        game = new Game();
    }

    @Test
    public void startGame() {
        Game game = new Game("lion", "Dr. M");
        assertEquals(10, game.getPoints());
    }

    // ===== CONTROL FLOW TESTS FOR countCorrectLetters() =====

    /**
     * Test Sequence 1: Empty guesses list
     * Covers nodes: 1, 2, 9 (path: entry → isEmpty check → return 0)
     * Covers edge: 2→9 (guesses.isEmpty() == true)
     */
    @Test
    public void testCountCorrectLetters_EmptyGuesses() {
        game.initGame("lion", "Player");
        // No guesses made, so guesses list is empty
        int result = game.countCorrectLetters();
        assertEquals("Should return 0 when no guesses made", 0, result);
    }

    /**
     * Test Sequence 2: Non-empty guesses, word with guessed letters
     * Covers nodes: 1, 2, 3, 4, 5, 6, 8, 10 (contains branch taken)
     * Covers edges: 2→3, 3→4, 4→5, 5→6, 6→3, 3→8, 8→10
     */
    @Test
    public void testCountCorrectLetters_WithGuessedLetters() {
        game.initGame("cat", "Player");
        game.makeGuess("c"); // Add to guesses
        game.makeGuess("a"); // Add to guesses
        int result = game.countCorrectLetters();
        assertEquals("Should count guessed letters correctly", 2, result);
    }

    /**
     * Test Sequence 3: Non-empty guesses, word with unguessed letters
     * Covers nodes: 1, 2, 3, 4, 5, 7, 8, 10 (else branch taken)
     * Covers edges: 2→3, 3→4, 4→5, 5→7, 7→3, 3→8, 8→10
     */
    @Test
    public void testCountCorrectLetters_WithUnguessedLetters() {
        game.initGame("cat", "Player");
        game.makeGuess("x"); // Add letter not in word
        game.makeGuess("y"); // Add letter not in word
        int result = game.countCorrectLetters();
        assertEquals("Should return 0 when no letters match", 0, result);
    }

    /**
     * Test Sequence 4: Mixed scenario - some letters guessed, some not
     * Covers both branches of inner if statement (5→6 and 5→7)
     * Ensures complete edge coverage for the contains check
     */
    @Test
    public void testCountCorrectLetters_MixedGuesses() {
        game.initGame("lion", "Player");
        game.makeGuess("l"); // In word
        game.makeGuess("x"); // Not in word
        game.makeGuess("i"); // In word
        int result = game.countCorrectLetters();
        assertEquals("Should count only the correct letters", 2, result);
    }

    // ===== TESTS FOR OTHER GAME METHODS =====

    @Test
    public void testCountLetters_SingleOccurrence() {
        game.initGame("lion", "Player");
        int count = game.countLetters('l');
        assertEquals("Letter 'l' appears once in 'lion'", 1, count);
    }

    @Test
    public void testCountLetters_MultipleOccurrences() {
        game.initGame("book", "Player");
        int count = game.countLetters('o');
        assertEquals("Letter 'o' appears twice in 'book'", 2, count);
    }

    @Test
    public void testCountLetters_NotInWord() {
        game.initGame("lion", "Player");
        int count = game.countLetters('z');
        assertEquals("Letter 'z' does not appear in 'lion'", 0, count);
    }

    @Test
    public void testGetAnswer_ReturnsLowercase() {
        game.initGame("LION", "Player");
        String answer = game.getAnswer();
        assertEquals("Should return lowercase answer", "lion", answer);
    }

    @Test
    public void testGetName() {
        game.initGame("lion", "Dr. M");
        String name = game.getName();
        assertEquals("Should return player name", "Dr. M", name);
    }

    @Test
    public void testGetGameStatus_Initial() {
        game.initGame("lion", "Player");
        int status = game.getGameStatus();
        assertEquals("Initial game status should be 0 (in progress)", 0, status);
    }

    @Test
    public void testGetGameStatus_Won() {
        game.initGame("lion", "Player");
        game.makeGuess("lion"); // Win the game
        int status = game.getGameStatus();
        assertEquals("Game status should be 1 when won", 1, status);
    }

    @Test
    public void testGetGameStatus_GameOver() {
        game.initGame("lion", "Player");
        // Make 10 wrong guesses with valid letters
        String wrongLetters = "abcdefghjk"; // Letters not in "lion"
        for (int i = 0; i < 10; i++) {
            game.makeGuess(String.valueOf(wrongLetters.charAt(i)));
        }
        int status = game.getGameStatus();
        assertEquals("Game status should be 2 when game over", 2, status);
    }

    @Test
    public void testSetPoints() {
        game.initGame("lion", "Player");
        game.setPoints(15);
        int points = game.getPoints();
        assertEquals("Should set points correctly", 15, points);
    }

    @Test
    public void testSetPoints_NegativeValue() {
        game.initGame("lion", "Player");
        game.setPoints(-5);
        int points = game.getPoints();
        assertEquals("Should allow negative points", -5, points);
    }

    @Test
    public void testInitGame_ResetsState() {
        game.initGame("lion", "Player");
        game.makeGuess("l"); // Make a guess
        game.setPoints(5); // Change points

        // Re-initialize with new game
        game.initGame("cat", "NewPlayer");

        assertEquals("Should reset points to 10", 10, game.getPoints());
        assertEquals("Should reset game status to 0", 0, game.getGameStatus());
        assertEquals("Should set new answer", "cat", game.getAnswer());
        assertEquals("Should set new player name", "NewPlayer", game.getName());
    }

    @Test
    public void testConstructor_WithName() {
        Game newGame = new Game("TestPlayer");
        assertEquals("Should set player name", "TestPlayer", newGame.getName());
        assertEquals("Should initialize points to 10", 10, newGame.getPoints());
        assertEquals("Should set game status to 0", 0, newGame.getGameStatus());
        assertNotNull("Should set a random word", newGame.getAnswer());
        assertFalse("Answer should not be empty", newGame.getAnswer().isEmpty());
    }

    @Test
    public void testConstructor_WithWordAndName() {
        Game newGame = new Game("elephant", "TestPlayer");
        assertEquals("Should set player name", "TestPlayer", newGame.getName());
        assertEquals("Should set answer", "elephant", newGame.getAnswer());
        assertEquals("Should initialize points to 10", 10, newGame.getPoints());
        assertEquals("Should set game status to 0", 0, newGame.getGameStatus());
    }

    @Test
    public void testConstructor_Default() {
        Game newGame = new Game();
        assertEquals("Should set empty name", "", newGame.getName());
        assertEquals("Should set empty answer", "", newGame.getAnswer());
        assertEquals("Should initialize points to 10", 10, newGame.getPoints());
        assertEquals("Should set game status to 0", 0, newGame.getGameStatus());
    }

    @Test
    public void testSetRandomWord() {
        game.setRandomWord();
        String answer = game.getAnswer();
        assertNotNull("Answer should not be null", answer);
        assertFalse("Answer should not be empty", answer.isEmpty());

        // Check if it's one of the expected animals
        String[] expectedAnimals = {"dog", "horse", "pony", "cat", "lion", "bear", "lioncub"};
        boolean isValidAnimal = false;
        for (String animal : expectedAnimals) {
            if (animal.equals(answer)) {
                isValidAnimal = true;
                break;
            }
        }
        assertTrue("Answer should be one of the predefined animals", isValidAnimal);
    }

    // ===== BOUNDARY VALUE TESTS =====

    @Test
    public void testCountLetters_EmptyAnswer() {
        game.initGame("", "Player");
        int count = game.countLetters('a');
        assertEquals("Should return 0 for empty answer", 0, count);
    }

    @Test
    public void testCountCorrectLetters_SingleCharacterAnswer() {
        game.initGame("a", "Player");
        game.makeGuess("a");
        int result = game.countCorrectLetters();
        assertEquals("Should handle single character answer", 1, result);
    }

    @Test
    public void testMakeGuess_BoundaryTenGuesses() {
        game.initGame("lion", "Player");
        // Make exactly 9 wrong guesses with valid letters
        for (int i = 0; i < 9; i++) {
            char letter = (char) ('a' + i); // a, b, c, d, e, f, g, h, i
            double result = game.makeGuess(String.valueOf(letter));
            assertNotEquals("Should not be game over yet", 5.0, result, 0.0);
        }

        // 10th guess should trigger game over (using 'j' which is valid)
        double result = game.makeGuess("j");
        assertEquals("10th guess should trigger game over", 5.0, result, 0.0);
        assertEquals("Game status should be 2", 2, game.getGameStatus());
    }

    // ===== ERROR CONDITION TESTS =====

    @Test
    public void testMakeGuess_CaseSensitivity() {
        game.initGame("Lion", "Player");
        double result1 = game.makeGuess("lion");
        assertEquals("Should handle case insensitive word guess", 0.0, result1, 0.0);

        game.initGame("Lion", "Player"); // Reset
        double result2 = game.makeGuess("L");
        assertEquals("Should handle case insensitive letter guess", 1.1, result2, 0.0);
    }

    @Test
    public void testMakeGuess_PointsCanBeNegative() {
        game.initGame("a", "Player");
        // Make several invalid guesses to drive points negative
        game.makeGuess("123"); // -3 points (7 total)
        game.makeGuess("456"); // -3 points (4 total)
        game.makeGuess("789"); // -3 points (1 total)
        game.makeGuess("abc"); // -3 points (-2 total)

        assertTrue("Points should be able to go negative", game.getPoints() < 0);
    }

    // ===== ADDITIONAL TESTS FOR BETTER COVERAGE =====

    @Test
    public void testMakeGuess_PartialMatchEdgeCase() {
        game.initGame("elephant", "Player");
        double result = game.makeGuess("ele");
        assertEquals("Partial match should return 3.0", 3.0, result, 0.0);
        assertEquals("Should add 2 points for partial match", 12, game.getPoints());
    }

    @Test
    public void testMakeGuess_ExactLengthButWrongWord() {
        game.initGame("lion", "Player");
        double result = game.makeGuess("bear");
        assertEquals("Same length wrong word should return 2.0", 2.0, result, 0.0);
        assertEquals("Should add 1 point", 11, game.getPoints());
    }

    @Test
    public void testMakeGuess_VeryLongWord() {
        game.initGame("cat", "Player");
        double result = game.makeGuess("supercalifragilisticexpialidocious");
        assertEquals("Very long word should return 2.1", 2.1, result, 0.0);
        assertTrue("Points should be heavily reduced", game.getPoints() < 0);
    }

    @Test
    public void testCountCorrectLetters_ReturnsCalculatedValue() {
        // This test specifically targets the bug fix in countCorrectLetters
        game.initGame("test", "Player");
        game.makeGuess("t");
        game.makeGuess("e");
        int result = game.countCorrectLetters();
        // "test" has 't' at positions 0 and 3, 'e' at position 1
        // So with guesses 't' and 'e', we should get: t-e-_-t = 3 positions filled
        assertEquals("Should return count of correct letter positions", 3, result);
    }

    @Test
    public void testRandomWordGeneration_MultipleCallsProduceValidWords() {
        String[] validAnimals = {"dog", "horse", "pony", "cat", "lion", "bear", "lioncub"};

        // Test multiple random generations
        for (int i = 0; i < 10; i++) {
            game.setRandomWord();
            String answer = game.getAnswer();

            boolean isValid = false;
            for (String animal : validAnimals) {
                if (animal.equals(answer)) {
                    isValid = true;
                    break;
                }
            }
            assertTrue("Random word should always be from valid list", isValid);
        }
    }

    @Test
    public void testGameStateTransitions_CompleteFlow() {
        game.initGame("cat", "Player");

        // Initial state
        assertEquals("Should start in progress", 0, game.getGameStatus());

        // Make some wrong guesses
        game.makeGuess("x");
        assertEquals("Should remain in progress", 0, game.getGameStatus());

        // Win the game
        game.makeGuess("cat");
        assertEquals("Should be won", 1, game.getGameStatus());

        // Try to guess after winning
        double result = game.makeGuess("y");
        assertEquals("Should return 5.1 after winning", 5.1, result, 0.0);
    }

    @Test
    public void testEdgeCaseEmptyAnswer() {
        game.initGame("", "Player");
        game.makeGuess("a");
        int result = game.countCorrectLetters();
        assertEquals("Empty answer should return 0", 0, result);
    }

    @Test
    public void testMakeGuess_SpaceCharacter() {
        game.initGame("lion", "Player");
        double result = game.makeGuess(" ");
        assertEquals("Space should be invalid", 4.1, result, 0.0);
    }

    @Test
    public void testMakeGuess_SpecialCharacters() {
        game.initGame("lion", "Player");
        double result = game.makeGuess("!@#$");
        assertEquals("Special characters should be invalid", 4.1, result, 0.0);
    }
}