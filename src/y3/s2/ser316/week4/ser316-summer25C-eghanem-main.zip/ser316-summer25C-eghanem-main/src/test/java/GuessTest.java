import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * White-box test class for testing the makeGuess method in Game.java
 * Adapted from Assignment 2 black-box tests to focus on single implementation
 */
public class GuessTest {

    private Game game;

    @Before
    public void setUp() throws Exception {
        game = new Game();
    }

    @Test
    public void testCorrectWordGuess() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("lion");
        assertEquals("Should return 0.0 for correct word", 0.0, response, 0.0);
        assertEquals("Should add word length points", 14, game.getPoints());
        assertEquals("Should set game status to won", 1, game.getGameStatus());
    }

    @Test
    public void testCorrectWordGuessCaseInsensitive() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("LION");
        assertEquals("Should be case insensitive", 0.0, response, 0.0);
        assertEquals("Should add word length points", 14, game.getPoints());
        assertEquals("Should set game status to won", 1, game.getGameStatus());
    }

    @Test
    public void testSingleLetterInWordOnce() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("l");
        assertEquals("Letter appears once should return 1.1", 1.1, response, 0.0);
        assertEquals("Should add 1 point", 11, game.getPoints());
        assertEquals("Game should continue", 0, game.getGameStatus());
    }

    @Test
    public void testSingleLetterInWordTwice() {
        game.initGame("book", "Dr. M");
        double response = game.makeGuess("o");
        assertEquals("Letter appears twice should return 1.2", 1.2, response, 0.0);
        assertEquals("Should add 2 points", 12, game.getPoints());
        assertEquals("Game should continue", 0, game.getGameStatus());
    }

    @Test
    public void testSingleLetterNotInWord() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("z");
        assertEquals("Letter not in word should return 1.0", 1.0, response, 0.0);
        assertEquals("Points should not change", 10, game.getPoints());
        assertEquals("Game should continue", 0, game.getGameStatus());
    }

    @Test
    public void testCorrectLengthWrongWord() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("bear");
        assertEquals("Same length wrong word should return 2.0", 2.0, response, 0.0);
        assertEquals("Should add 1 point", 11, game.getPoints());
        assertEquals("Game should continue", 0, game.getGameStatus());
    }

    @Test
    public void testWordTooLong() {
        game.initGame("cat", "Dr. M");
        double response = game.makeGuess("elephant");
        assertEquals("Word too long should return 2.1", 2.1, response, 0.0);
        assertTrue("Points should be reduced", game.getPoints() < 10);
        assertEquals("Game should continue", 0, game.getGameStatus());
    }

    @Test
    public void testWordTooShort() {
        game.initGame("elephant", "Dr. M");
        double response = game.makeGuess("cat");
        assertEquals("Word too short should return 2.2", 2.2, response, 0.0);
        assertTrue("Points should be reduced", game.getPoints() < 10);
        assertEquals("Game should continue", 0, game.getGameStatus());
    }

    @Test
    public void testPartialWordMatch() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("li");
        assertEquals("Partial match should return 3.0", 3.0, response, 0.0);
        assertEquals("Should add 2 points", 12, game.getPoints());
        assertEquals("Game should continue", 0, game.getGameStatus());
    }

    @Test
    public void testAlreadyGuessedLetter() {
        game.initGame("lion", "Dr. M");
        game.makeGuess("l"); // First guess
        double response = game.makeGuess("l"); // Repeat guess
        assertEquals("Already guessed should return 4.0", 4.0, response, 0.0);
        assertEquals("Should reduce 2 points from previous score", 9, game.getPoints());
        assertEquals("Game should continue", 0, game.getGameStatus());
    }

    @Test
    public void testAlreadyGuessedWord() {
        game.initGame("lion", "Dr. M");
        game.makeGuess("bear"); // First guess
        double response = game.makeGuess("bear"); // Repeat guess
        assertEquals("Already guessed should return 4.0", 4.0, response, 0.0);
        assertEquals("Should reduce 2 points from previous score", 9, game.getPoints());
        assertEquals("Game should continue", 0, game.getGameStatus());
    }

    @Test
    public void testInvalidCharactersWithNumbers() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("l1on");
        assertEquals("Invalid characters should return 4.1", 4.1, response, 0.0);
        assertEquals("Should reduce 3 points", 7, game.getPoints());
        assertEquals("Game should continue", 0, game.getGameStatus());
    }

    @Test
    public void testInvalidCharactersWithSymbols() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("l@on");
        assertEquals("Invalid characters should return 4.1", 4.1, response, 0.0);
        assertEquals("Should reduce 3 points", 7, game.getPoints());
        assertEquals("Game should continue", 0, game.getGameStatus());
    }

    @Test
    public void testEmptyGuess() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("");
        assertEquals("Empty string should return 4.1", 4.1, response, 0.0);
        assertEquals("Should reduce 3 points", 7, game.getPoints());
        assertEquals("Game should continue", 0, game.getGameStatus());
    }

    @Test
    public void testGameOverAfterTenGuesses() {
        game.initGame("lion", "Dr. M");
        // Make 10 wrong guesses
        for (int i = 0; i < 10; i++) {
            game.makeGuess("z" + i);
        }
        double response = game.makeGuess("a"); // 11th guess attempt
        assertEquals("Game over should return 5.1", 5.1, response, 0.0);
        assertEquals("Game status should be game over", 2, game.getGameStatus());
    }

    @Test
    public void testGuessAfterGameOver() {
        game.initGame("lion", "Dr. M");
        // Make 10 wrong guesses to end game
        for (int i = 0; i < 10; i++) {
            game.makeGuess("z" + i);
        }
        game.makeGuess("a"); // This ends the game
        double response = game.makeGuess("b"); // This should return 5.1
        assertEquals("Guess after game over should return 5.1", 5.1, response, 0.0);
        assertEquals("Game status should remain game over", 2, game.getGameStatus());
    }

    @Test
    public void testGuessAfterWinning() {
        game.initGame("lion", "Dr. M");
        game.makeGuess("lion"); // Win the game
        double response = game.makeGuess("l"); // Guess after winning
        assertEquals("Guess after winning should return 5.1", 5.1, response, 0.0);
        assertEquals("Game status should remain won", 1, game.getGameStatus());
    }

    @Test
    public void testSpacesInGuess() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("li on");
        assertEquals("Spaces should be invalid", 4.1, response, 0.0);
        assertEquals("Should reduce 3 points", 7, game.getPoints());
    }

    @Test
    public void testMultipleLettersNotFormingWord() {
        game.initGame("lion", "Dr. M");
        double response = game.makeGuess("xyz");
        assertEquals("Multiple letters not in word, not partial match", 2.2, response, 0.0);
        assertTrue("Points should be reduced for wrong length", game.getPoints() < 10);
    }
}