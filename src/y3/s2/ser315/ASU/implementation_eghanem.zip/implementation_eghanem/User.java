package y3.s2.ser315.week3.implementation_eghanem;

/**
 * User class represents the base user in our system.
 */
public abstract class User {
    public String userName;
    public String password;
    public String email;
}