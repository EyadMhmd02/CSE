import java.time.LocalDateTime;
import java.util.LinkedList;

public class Main{
    static LocalDateTime now = LocalDateTime.now();
    static LinkedList<Appointment> appointments = new LinkedList<>();
    static LinkedList<Student> students = new LinkedList<>();
    static LinkedList<Tutor> tutors = new LinkedList<>();

    public static void main(String[] args) {
        // Create developers
        Developer epicGames = new Developer("Epic Games");
        Developer valve = new Developer("Valve");
        Developer rockstar = new Developer("Rockstar Games");

        // Create games
        Game fortnite = new Game("Fortnite", epicGames, 0.0);
        Game csgo = new Game("CS:GO", valve, 0.0);
        Game gta5 = new Game("GTA V", rockstar, 29.99);

        // Add games to developers
        epicGames.addGame(fortnite);
        valve.addGame(csgo);
        rockstar.addGame(gta5);

        // Create gamers
        Gamer gamer1 = new Gamer("Player1", "player1@email.com");
        Gamer gamer2 = new Gamer("Player2", "player2@email.com");
        Gamer gamer3 = new Gamer("Player3", "player3@email.com");

        // Add games to gamers
        gamer1.addGame(fortnite);
        gamer1.addGame(csgo);
        gamer2.addGame(gta5);
        gamer3.addGame(fortnite);

        // Create review control
        ReviewControl reviewControl = new ReviewControl();

        // Test cases
        System.out.println("=== Testing Review System ===");

        // Test 1: Valid review
        System.out.println("\nTest 1: Valid review");
        String result1 = reviewControl.addReview(gamer1, fortnite, 5, "Great game!");
        System.out.println(result1);

        // Test 2: Gamer doesn't own the game
        System.out.println("\nTest 2: Gamer doesn't own the game");
        String result2 = reviewControl.addReview(gamer2, csgo, 4, "Good game");
        System.out.println(result2);

        // Test 3: Invalid rating
        System.out.println("\nTest 3: Invalid rating");
        String result3 = reviewControl.addReview(gamer3, fortnite, 6, "Amazing!");
        System.out.println(result3);

        // Test 4: Another valid review
        System.out.println("\nTest 4: Another valid review");
        String result4 = reviewControl.addReview(gamer1, csgo, 4, "Classic FPS");
        System.out.println(result4);

        // Display all reviews
        reviewControl.displayReviews();
    }


    public static String cancelAppointment(int appointmentId, String email, boolean isSick){
        Student tempStu = null;

        //find student in list of students from the system
        //we assume student exists
        for(Student stu : students) {
            if(email.equals(stu.email)){
                tempStu = stu;
                break;
            }
        }

        //find appointment in list of appointment from system
        //we assume appointment exists
        Appointment tempApp = null;
        for(Appointment app : appointments) {
            if (appointmentId == app.appointmentId) {
                tempApp = app;
                break;
            }
        }

        String event;

        if(!tempStu.appointments.contains(tempApp)){
            event = "Student is not registered for appointment with id: " + appointmentId + "\n"; // id of appointment added not 100% consistent to SD but helps clarify what happened
        }
        else {
            //if Appointment is < 24 hours before appointment Start Time.
            if(tempApp.startTime.minusHours(24).isBefore(now)) {
                if(isSick) {
                    event = "Student: Appointment cancelled provide proof for refund\n" +
                    "Tutor: Appointment with ID: " + appointmentId+ " has been cancelled by student\n"; // id of appointment added not 100% consistent to SD but helps clarify what happened
                } else {
                    event = "Student: Appointment Cancelled, no refund issued\n" +
                    "Tutor: Appointment with ID: " + appointmentId+ " has been cancelled by student\n"; // id of appointment added not 100% consistent to SD but helps clarify what happened
                }
            } else {
                event = "Student: Appointment Cancelled, refund issued\n" +
                "Tutor: Appointment with ID: " + appointmentId+ " has been cancelled by student\n";
            }
        }
        return event;
    }
}