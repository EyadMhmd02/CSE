import java.util.List;
import java.util.ArrayList;

public class Developer {
    private String name;
    private List<Game> games;

    public Developer(String name) {
        this.name = name;
        this.games = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public List<Game> getGames() {
        return games;
    }

    public void addGame(Game game) {
        games.add(game);
    }

    @Override
    public String toString() {
        return "Developer: " + name;
    }
} 