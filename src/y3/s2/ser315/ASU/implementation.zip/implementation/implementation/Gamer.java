import java.util.List;
import java.util.ArrayList;

public class Gamer {
    private String username;
    private String email;
    private List<Game> ownedGames;
    private List<Review> reviews;

    public Gamer(String username, String email) {
        this.username = username;
        this.email = email;
        this.ownedGames = new ArrayList<>();
        this.reviews = new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public List<Game> getOwnedGames() {
        return ownedGames;
    }

    public List<Review> getReviews() {
        return reviews;
    }

    public void addGame(Game game) {
        ownedGames.add(game);
    }

    public void addReview(Review review) {
        reviews.add(review);
    }

    @Override
    public String toString() {
        return "Gamer: " + username + " (" + email + ")";
    }
} 