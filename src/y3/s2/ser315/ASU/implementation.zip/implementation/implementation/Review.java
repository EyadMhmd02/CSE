public class Review {
    private Gamer gamer;
    private Game game;
    private int rating;
    private String comment;

    public Review(Gamer gamer, Game game, int rating, String comment) {
        this.gamer = gamer;
        this.game = game;
        this.rating = rating;
        this.comment = comment;
    }

    public Gamer getGamer() {
        return gamer;
    }

    public Game getGame() {
        return game;
    }

    public int getRating() {
        return rating;
    }

    public String getComment() {
        return comment;
    }

    @Override
    public String toString() {
        return "Review by " + gamer.getUsername() + " for " + game.getTitle() + 
               ": " + rating + "/5 - " + comment;
    }
} 