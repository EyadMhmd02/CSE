import java.util.List;
import java.util.ArrayList;

public class ReviewControl {
    private List<Review> reviews;

    public ReviewControl() {
        this.reviews = new ArrayList<>();
    }

    public String addReview(Gamer gamer, Game game, int rating, String comment) {
        // Check if gamer owns the game
        if (!gamer.getOwnedGames().contains(game)) {
            return "Error: Gamer does not own this game";
        }

        // Check if rating is valid (1-5)
        if (rating < 1 || rating > 5) {
            return "Error: Rating must be between 1 and 5";
        }

        // Create and add the review
        Review review = new Review(gamer, game, rating, comment);
        reviews.add(review);
        gamer.addReview(review);
        game.addReview(review);

        return "Review added successfully";
    }

    public List<Review> getReviews() {
        return reviews;
    }

    public void displayReviews() {
        System.out.println("\n=== All Reviews ===");
        for (Review review : reviews) {
            System.out.println(review);
        }
    }
} 