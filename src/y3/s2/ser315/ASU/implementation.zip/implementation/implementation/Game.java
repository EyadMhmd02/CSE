import java.util.List;
import java.util.ArrayList;

public class Game {
    private String title;
    private Developer developer;
    private List<Review> reviews;
    private double price;

    public Game(String title, Developer developer, double price) {
        this.title = title;
        this.developer = developer;
        this.price = price;
        this.reviews = new ArrayList<>();
    }

    public String getTitle() {
        return title;
    }

    public Developer getDeveloper() {
        return developer;
    }

    public List<Review> getReviews() {
        return reviews;
    }

    public double getPrice() {
        return price;
    }

    public void addReview(Review review) {
        reviews.add(review);
    }

    @Override
    public String toString() {
        return "Game: " + title + " by " + developer.getName() + " ($" + price + ")";
    }
} 