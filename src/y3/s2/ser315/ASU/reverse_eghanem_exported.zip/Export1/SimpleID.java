public class SimpleID {

	private static int counter;

	public static String generate() {
		return null;
	}

}
