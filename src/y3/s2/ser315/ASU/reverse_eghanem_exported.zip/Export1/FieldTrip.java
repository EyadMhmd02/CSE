public class FieldTrip {

	public FieldTrip(Course course) {

	}

	public int makeWrittenObservation(String stu, String summ, String descr) {
		return 0;
	}

	public int makePhotoObservation(String stu, String imgURL, Double dLat, Double dLong) {
		return 0;
	}

	public List<String> getStudentNames() {
		return null;
	}

	public List_RecorderObservation_ getObservations() {
		return null;
	}

	public int getObservationsCount() {
		return 0;
	}

	public RecordedObservation getRecordedObservations(Student stu) {
		return null;
	}

}
