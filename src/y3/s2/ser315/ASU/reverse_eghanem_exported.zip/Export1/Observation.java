public abstract class Observation {

	private String id;

	private LocalDateTime datetime;

	private SimpleID simpleID;

	Observation() {

	}

	public String getId() {
		return null;
	}

	public String read() {
		return null;
	}

	public String getDatetime() {
		return null;
	}

}
