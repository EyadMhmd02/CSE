public class Person {

	int name;

	int email;

	public int getName() {
		return 0;
	}

	public String getEmail() {
		return null;
	}

	public String toString() {
		return null;
	}

}
