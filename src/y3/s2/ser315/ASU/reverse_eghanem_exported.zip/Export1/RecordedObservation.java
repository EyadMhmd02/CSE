public class RecordedObservation {

	public RecordedObservation(Student student) {

	}

	public int photoObservation() {
		return 0;
	}

	public int writeObervation() {
		return 0;
	}

	public int writeObservation() {
		return 0;
	}

	public Student getStudent() {
		return null;
	}

	public List<Observation> getObservations() {
		return null;
	}

	public int getObservationCount() {
		return 0;
	}

	public void addObservation() {

	}

}
