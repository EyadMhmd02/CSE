public class PhotoObservation extends Observation {

	private int imageURL;

	private Double latitude;

	private Double longitude;

	public PhotoObservation(String photo) {

	}

	public void PhotoObservation(String photo, Double dLat, Double dLong) {

	}

	public String read() {
		return null;
	}

	public String getImageURL() {
		return null;
	}

	public String getLatitude() {
		return null;
	}

}
