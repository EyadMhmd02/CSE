public class WrittenObservation extends Observation {

	private String summary;

	private String description;

	public WrittenObservation(String summary) {

	}

	public WrittenObservation(String summary, String descr) {

	}

	public String read() {
		return null;
	}

	public String getSummary() {
		return null;
	}

	public String getDescription() {
		return null;
	}

}
