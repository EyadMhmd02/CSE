public class Student extends Person {

	private String major;

	private String favColor;

	public void Student(String name, String email, String major, String color) {

	}

	public Student(String name, String email, String major) {

	}

	public Student(String name, String email) {

	}

	public String getMajor() {
		return null;
	}

	public String getFavColor() {
		return null;
	}

	public String toString() {
		return null;
	}

}
