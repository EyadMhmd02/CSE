package src;

import java.util.List;

public class FieldTrip {

	private Course course;

	private RecordedObservations[] observations;

	public FieldTrip(Course course) {

	}

	public int makeWrittenObservation(Student stu, String summ, String descr) {
		return 0;
	}

	public int makePhotoObservation(Student stu, String imgURL, Double dLat, Double dLong) {
		return 0;
	}

	public List<String> getStudentNames() {
		return null;
	}

	public List<RecordedObservations> getObservations() {
		return null;
	}

	public int getObservationCount() {
		return 0;
	}

	private RecordedObservations getRecordedObservations(Student stu) {
		return null;
	}

}
