package y3.s2.ser315.week7.attempt.Strategy_eghanem;

// AttackStrategy.java
public interface AttackStrategy {
    int attack(int strength);
}