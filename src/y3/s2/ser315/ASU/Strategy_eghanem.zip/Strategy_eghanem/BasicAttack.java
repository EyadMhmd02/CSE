package y3.s2.ser315.week7.attempt.Strategy_eghanem;

// BasicAttack.java
public class BasicAttack implements AttackStrategy {
    @Override
    public int attack(int strength) {
        return strength;
    }
}
