package y3.s2.ser315.week7.attempt.Strategy_eghanem;

// DefenseStrategy.java
public interface DefenseStrategy {
    int defend(int damage, int resilience);
}
