package y3.s2.ser315.week2.Assignment.tutoring_system;

import java.util.ArrayList;
import java.util.List;

public class Tutor {
    public String name;
    public String email;
    public List<Subject> subjects = new ArrayList<>();
    public List<Appointment> appointments = new ArrayList<>();

    // Method to receive notification when appointment is cancelled
    public void receiveAppointmentCancellation(Appointment appointment, String reason) {
        System.out.println("Tutor " + this.name + " received notification: " +
                "Appointment " + appointment.id + " cancelled. Reason: " + reason);

        // Remove appointment from tutor's list
        appointments.remove(appointment);
    }
}