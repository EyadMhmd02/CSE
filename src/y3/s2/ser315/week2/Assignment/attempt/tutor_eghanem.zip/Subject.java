package y3.s2.ser315.week2.Assignment.tutoring_system;

public class Subject {
    public String name;
}