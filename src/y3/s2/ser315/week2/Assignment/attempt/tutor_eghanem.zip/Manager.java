package y3.s2.ser315.week2.Assignment.tutoring_system;

public class Manager {
    public String loginName;
    public String password;
}