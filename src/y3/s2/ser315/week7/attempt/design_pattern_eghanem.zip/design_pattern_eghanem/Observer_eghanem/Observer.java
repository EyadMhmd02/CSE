package y3.s2.ser315.week7.attempt.design_pattern_eghanem.Observer_eghanem;

// Observer interface
public interface Observer {
    void update(Appointment appointment, String action);
}