package y3.s2.ser315.week7.attempt.design_pattern_eghanem.Builder_eghanem;

class Student {
    private String name;

    public Student(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
