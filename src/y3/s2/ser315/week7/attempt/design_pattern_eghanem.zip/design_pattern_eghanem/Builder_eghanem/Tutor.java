package y3.s2.ser315.week7.attempt.design_pattern_eghanem.Builder_eghanem;

class Tutor {
    private String name;

    public Tutor(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
