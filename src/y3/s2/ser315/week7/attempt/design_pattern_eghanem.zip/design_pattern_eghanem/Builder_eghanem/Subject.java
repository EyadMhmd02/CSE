package y3.s2.ser315.week7.attempt.design_pattern_eghanem.Builder_eghanem;

class Subject {
    private String name;

    public Subject(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
