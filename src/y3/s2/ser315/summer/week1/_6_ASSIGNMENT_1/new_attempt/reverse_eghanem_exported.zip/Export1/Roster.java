public class Roster {

	public Roster(int course) {

	}

	public boolean addStudent(Student student) {
		return false;
	}

}
